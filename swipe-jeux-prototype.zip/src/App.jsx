import React, {useState, useMemo, useEffect} from "react";

/*
Simple "Tinder for games" prototype.
- No backend. Data stored in localStorage.
- Uses a small list of well-known games with external image URLs.
- Like / Dislike produces a numeric profile (genre weights) and simple recommendations.
*/

const GAMES = [
  { id: 1, title: "The Witcher 3", genres: ["RPG","Adventure"], img: "https://media.rawg.io/media/games/456/456dea5e1c7e3cd07060c14e96612001.jpg", meta: "Open-world story-driven RPG" },
  { id: 2, title: "Mario Kart 8 Deluxe", genres: ["Racing","Multiplayer"], img: "https://upload.wikimedia.org/wikipedia/en/8/8a/MarioKart8Boxart.jpg", meta: "Arcade racing, family-friendly" },
  { id: 3, title: "Fortnite", genres: ["Shooter","Battle Royale","Multiplayer"], img: "https://media.rawg.io/media/games/1ea/1ea9c6e71a3d2a3d2dbb0f6f2a7b5f93.jpg", meta: "Fast-paced shooter / builder" },
  { id: 4, title: "Stardew Valley", genres: ["Simulation","RPG","Casual"], img: "https://media.rawg.io/media/games/ccf/ccf8ee56a3aeb7f3b4d4f6d4b6b2f1d0.jpg", meta: "Farming life-sim" },
  { id: 5, title: "Dark Souls", genres: ["Action","RPG","Difficult"], img: "https://upload.wikimedia.org/wikipedia/en/5/5a/Dark_Souls.jpg", meta: "Challenging action-RPG" },
  { id: 6, title: "Overwatch", genres: ["Shooter","Multiplayer","Team-based"], img: "https://media.rawg.io/media/games/3c3/3c365e7e3b5f6d6b4c5a6d7e8f9a0b1c.jpg", meta: "Hero shooter with team roles" },
  { id: 7, title: "Minecraft", genres: ["Sandbox","Creative","Survival"], img: "https://media.rawg.io/media/games/456/456dea5e1c7e3cd07060c14e96612001.jpg", meta: "Open sandbox" },
  { id: 8, title: "Civilization VI", genres: ["Strategy","Turn-based"], img: "https://media.rawg.io/media/games/8c1/8c1f8f3b6f9a2a3b4c5d6e7f8a9b0c1d.jpg", meta: "4X grand strategy" },
  { id: 9, title: "Among Us", genres: ["Party","Multiplayer","Social"], img: "https://upload.wikimedia.org/wikipedia/en/9/9a/Among_Us_cover_art.png", meta: "Social deduction party game" },
  { id: 10, title: "Hades", genres: ["Action","Roguelike","Indie"], img: "https://media.rawg.io/media/games/3f0/3f01322e6c4a7b8c9d0e1f2a3b4c5d6e.jpg", meta: "Action roguelike" }
];

// derive genre list
const ALL_GENRES = Array.from(new Set(GAMES.flatMap(g => g.genres))).sort();

function genresToVector(genres) {
  return ALL_GENRES.map(g => (genres.includes(g) ? 1 : 0));
}
function cosineSim(a,b){
  let dot=0, na=0, nb=0;
  for(let i=0;i<a.length;i++){dot+=a[i]*b[i]; na+=a[i]*a[i]; nb+=b[i]*b[i];}
  if(na===0||nb===0) return 0;
  return dot/(Math.sqrt(na)*Math.sqrt(nb));
}

export default function App(){
  const [deck, setDeck] = useState(GAMES);
  const [pos, setPos] = useState(0);
  const [likes, setLikes] = useState(() => {
    try { return JSON.parse(localStorage.getItem("sj.l")) || []; } catch(e){return [];}
  });
  const [dislikes, setDislikes] = useState(() => {
    try { return JSON.parse(localStorage.getItem("sj.d")) || []; } catch(e){return [];}
  });
  const [showProfile, setShowProfile] = useState(false);

  useEffect(()=>{ localStorage.setItem("sj.l", JSON.stringify(likes)); localStorage.setItem("sj.d", JSON.stringify(dislikes)); }, [likes, dislikes]);

  const top = deck[pos];

  // compute profile
  const profile = useMemo(()=>{
    if(likes.length===0) return Array(ALL_GENRES.length).fill(0);
    const sum = Array(ALL_GENRES.length).fill(0);
    for(const id of likes){
      const g = GAMES.find(x=>x.id===id);
      const v = genresToVector(g.genres);
      for(let i=0;i<v.length;i++) sum[i]+=v[i];
    }
    const max = Math.max(...sum);
    return max===0 ? sum : sum.map(v => v/max);
  }, [likes]);

  const recommendations = useMemo(()=>{
    const seen = new Set([...likes, ...dislikes]);
    return GAMES.filter(g => !seen.has(g.id)).map(g => ({...g, score: cosineSim(profile, genresToVector(g.genres))})).sort((a,b)=>b.score-a.score);
  }, [likes, dislikes, profile]);

  useEffect(()=>{
    function onKey(e){
      if(showProfile) return;
      if(e.key==="ArrowRight") doAction("like");
      if(e.key==="ArrowLeft") doAction("dislike");
      if(e.key==="Enter") setShowProfile(true);
    }
    window.addEventListener("keydown", onKey);
    return ()=> window.removeEventListener("keydown", onKey);
  }, [pos, showProfile, likes, dislikes]);

  function doAction(action){
    if(!top) return;
    if(action==="like") setLikes(prev => Array.from(new Set([...prev, top.id])));
    else setDislikes(prev => Array.from(new Set([...prev, top.id])));
    setPos(p => Math.min(p+1, deck.length));
  }

  function resetAll(){
    setLikes([]); setDislikes([]); setPos(0); setShowProfile(false);
    localStorage.removeItem("sj.l"); localStorage.removeItem("sj.d");
  }

  return (
    <div className="app">
      <header>
        <h1>SwipeJeux — Prototype</h1>
        <p>Swipe (← / →) ou clique Like / Dislike pour créer ton profil.</p>
      </header>
      <main>
        <section className="card-area">
          {top ? (
            <div className="card">
              <img src={top.img} alt={top.title} onError={(e)=>{e.target.style.opacity=0.6;}}/>
              <div className="card-body">
                <h2>{top.title}</h2>
                <p className="meta">{top.meta}</p>
                <div className="genres">{top.genres.join(" • ")}</div>
              </div>
            </div>
          ) : (
            <div className="card empty">
              <h2>Plus de jeux</h2>
              <p>Clique sur « Voir profil » pour voir ton profil numérique.</p>
            </div>
          )}
          <div className="controls">
            <button onClick={()=>doAction("dislike")}>Dislike ←</button>
            <button onClick={()=>setShowProfile(true)} className="neutral">Voir profil</button>
            <button onClick={()=>doAction("like")} className="like">Like →</button>
          </div>
          <div className="progress">Progress: {Math.round(((likes.length+dislikes.length)/deck.length)*100)}%</div>
        </section>

        <aside className="side">
          <div className="profile">
            <h3>Profil numérique</h3>
            <small>Basé sur les jeux que tu as aimés</small>
            <ul className="genre-list">
              {ALL_GENRES.map((g,i)=>(
                <li key={g}><strong>{g}</strong><span>{Math.round(profile[i]*100)}%</span></li>
              ))}
            </ul>
            <h4>Recommandations</h4>
            <ol className="reco">
              {recommendations.length===0 ? <li>(Aucune pour l'instant)</li> : recommendations.slice(0,6).map(r=>(
                <li key={r.id}><img src={r.img} alt="" onError={(e)=>e.target.style.display='none'} /> <div><strong>{r.title}</strong><div className="g">{r.genres.join(", ")}</div></div> <div className="score">{r.score.toFixed(2)}</div></li>
              ))}
            </ol>
            <div className="actions">
              <button onClick={resetAll}>Reset</button>
              <button onClick={()=>{navigator.clipboard && navigator.clipboard.writeText(JSON.stringify({likes,dislikes,profile})); alert("Profil copié dans le presse-papier !")}}>Copier profil</button>
            </div>
          </div>
        </aside>
      </main>

      {showProfile && (
        <div className="modal" onClick={()=>setShowProfile(false)}>
          <div className="modal-card" onClick={(e)=>e.stopPropagation()}>
            <h3>Ton profil numérique</h3>
            <p>Tu as liké {likes.length} jeu(x) — vecteur de genres :</p>
            <pre>{JSON.stringify({likes,dislikes,profile}, null, 2)}</pre>
            <div className="modal-actions"><button onClick={()=>setShowProfile(false)}>Fermer</button></div>
          </div>
        </div>
      )}

      <footer>Astuce: flèches ←/→ ou boutons. Les images proviennent d'Internet et peuvent mettre un instant à charger.</footer>
    </div>
  );
}
